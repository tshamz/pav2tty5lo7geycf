
"use strict";

const pnp = require("./.pnp.js").setup();

const index = require("./packages/notifications/index.js");

Object.defineProperty(exports, "__esModule", { value: true });

exports.default = index;
