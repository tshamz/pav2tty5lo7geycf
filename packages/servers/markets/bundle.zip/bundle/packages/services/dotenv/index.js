if (process.env.NODE_ENV === 'development') {
  require('dotenv').config({
    path: '/Users/tylershambora/Code/Personal/pav2tty5lo7geycf/.env',
  });
}
